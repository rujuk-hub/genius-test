# python-core
This project can help you to study Python and FastApi
