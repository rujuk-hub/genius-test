int = 5
print(type(int))

num_1 = 5
print(type(num_1))

num_2 = 3.14
print(type(num_2))

string = "hello"
print(type(string))

check = True
print(type(check))

lst = ["hello", "my", "name", "is", "Tom"]
print(type(lst))

tpl = (1, 2, 3)
print(type(tpl))

dct = {"name": "John", "age": 23}
print(type(dct))

set_ex = {1, 2, 3}
print(type(set_ex))

none_var = None
print(type(none_var))

class Person:
    pass

a = Person()
print(type(a))
