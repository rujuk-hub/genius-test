reserve_words = """
    False     await     else      import    pass
    None      break     except    in        raise
    True      class     finally   is        return
    and       continue  for       lambda    try
    as        def       from      nonlocal  while
    assert    del       global    not       with
    async     elif      if        or        yield
"""

name = "Tom"
Name = "Tom"
print(name, Name)

user_email = "example@gmail.com"
userEmail = "example@gmail.com"
print(user_email, userEmail)

name = "Jon"
print(name)
name = "Tom"
print(name)
