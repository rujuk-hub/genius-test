import my_module


my_module.hello("Tom")